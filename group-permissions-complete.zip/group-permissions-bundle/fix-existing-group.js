// Fix Existing Group - Run this in your browser console on the group page

// Replace 'YOUR_GROUP_ID' with your actual group ID from the URL
const groupId = window.location.pathname.split('/').pop(); // Gets group ID from URL
const userId = 'Q0T2dA2ENrThqtLP7EFmybIiyOg1'; // Your user ID from debug

console.log('Fixing group:', groupId, 'for user:', userId);

// 1. Add creatorId to group document
await updateDoc(doc(db, 'groups', groupId), {
  creatorId: userId,
  createdBy: userId // Also ensure this exists
});

// 2. Update user's role to creator in members subcollection
await updateDoc(doc(db, 'groups', groupId, 'members', userId), {
  role: 'creator',
  assignedBy: userId,
  assignedAt: new Date()
});

console.log('Group fixed! Refresh the page to see buttons.');

// Alternative: If you get import errors, use this format:
/*
import { doc, updateDoc } from 'firebase/firestore';
import { db } from './firebase'; // Adjust path as needed

async function fixGroup() {
  const groupId = 'YOUR_GROUP_ID_HERE';
  const userId = 'Q0T2dA2ENrThqtLP7EFmybIiyOg1';
  
  try {
    // Fix group document
    await updateDoc(doc(db, 'groups', groupId), {
      creatorId: userId,
      createdBy: userId
    });
    
    // Fix user role
    await updateDoc(doc(db, 'groups', groupId, 'members', userId), {
      role: 'creator',
      assignedBy: userId,
      assignedAt: new Date()
    });
    
    console.log('Group fixed successfully!');
  } catch (error) {
    console.error('Error fixing group:', error);
  }
}

fixGroup();
*/